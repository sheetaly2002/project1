<?php
include 'config.php'; // Aapki di hui config file jisme connection hai

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents("php://input"), true);

switch ($method) {
    
    // ================= 1. LOGIN & FETCH (POST/GET) =================
    case 'POST':
        // LOGIN LOGIC
        if (isset($data['action']) && $data['action'] == 'login') {
            $username = $data['username'];
            $password = $data['password'];

            $sql = "SELECT id, username, full_name, role FROM users WHERE username = '$username' AND password = '$password'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                echo json_encode(["status" => "success", "message" => "Login Successful", "user" => $user]);
            } else {
                echo json_encode(["status" => "error", "message" => "Invalid Username or Password"]);
            }
        } 
        // ADD USER LOGIC (Admin only)
        else {
            $username = $data['username'];
            $password = $data['password'];
            $full_name = $data['full_name'];
            $role = $data['role']; // 'admin' or 'staff'

            $sql = "INSERT INTO users (username, password, full_name, role) VALUES ('$username', '$password', '$full_name', '$role')";
            
            if ($conn->query($sql)) {
                echo json_encode(["status" => "success", "message" => "User added successfully"]);
            } else {
                echo json_encode(["status" => "error", "message" => $conn->error]);
            }
        }
        break;

    // ================= 2. READ ALL USERS (GET) =================
    case 'GET':
        $sql = "SELECT id, username, full_name, role, created_at FROM users";
        $result = $conn->query($sql);
        $users = [];
        
        while($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        echo json_encode(["status" => "success", "data" => $users]);
        break;

    // ================= 3. UPDATE USER (PUT) =================
    case 'PUT':
        $id = $data['id'];
        $full_name = $data['full_name'];
        $role = $data['role'];
        $password = $data['password'];

        $sql = "UPDATE users SET full_name='$full_name', role='$role', password='$password' WHERE id=$id";
        
        if ($conn->query($sql)) {
            echo json_encode(["status" => "success", "message" => "User updated successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => $conn->error]);
        }
        break;

    // ================= 4. DELETE USER (DELETE) =================
    case 'DELETE':
        $id = $data['id'];
        
        // Admin user khud ko delete na kar sake iska dhyan rakhein (Optional)
        $sql = "DELETE FROM users WHERE id=$id";
        
        if ($conn->query($sql)) {
            echo json_encode(["status" => "success", "message" => "User deleted successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => $conn->error]);
        }
        break;

    default:
        echo json_encode(["status" => "error", "message" => "Invalid Request"]);
        break;
}

$conn->close();
?>