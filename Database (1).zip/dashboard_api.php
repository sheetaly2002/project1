<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Aapki existing config file
include 'config.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$response = [
    "totalSales" => 0,
    "totalProfit" => 0,
    "totalStockWeight" => 0,
    "stockValue" => 0,
    "categoryWise" => []
];

try {
    // 1. Total Sales & Profit (Table: s_sales)
    // Aapke POST logic mein 'final_amount' aur 'total_profit' columns hain
    $salesQuery = "SELECT 
                    COALESCE(SUM(final_amount), 0) as total_rev, 
                    COALESCE(SUM(total_profit), 0) as net_profit 
                   FROM s_sales"; 
    $salesRes = $conn->query($salesQuery);
    if($salesRes && $row = $salesRes->fetch_assoc()){
        $response['totalSales'] = round((float)$row['total_rev'], 2);
        $response['totalProfit'] = round((float)$row['net_profit'], 2);
    }

    // 2. Current Stock (Table: s_stock)
    // Aapke POST logic mein status 'Sold' hota hai, toh yahan hum 'Available' uthayenge
    $stockQuery = "SELECT 
                    COALESCE(SUM(net_weight), 0) as total_wt, 
                    COALESCE(SUM(total_amount), 0) as total_val 
                   FROM s_stock 
                   WHERE status = 'Available'";
    $stockRes = $conn->query($stockQuery);
    if($stockRes && $row = $stockRes->fetch_assoc()){
        $response['totalStockWeight'] = round((float)$row['total_wt'], 3);
        $response['stockValue'] = round((float)$row['total_val'], 2);
    }

    // 3. Category wise Performance (Table: s_stock join s_products)
    // Kyunki s_stock mein product_id hai, humein s_products se category leni hogi
    $catQuery = "SELECT p.category, COUNT(*) as qty, SUM(s.net_weight) as wt 
                 FROM s_stock s
                 JOIN s_products p ON s.product_id = p.id
                 WHERE s.status = 'Available'
                 GROUP BY p.category";
    $catRes = $conn->query($catQuery);
    if($catRes){
        while($row = $catRes->fetch_assoc()){
            $response['categoryWise'][] = [
                "category" => $row['category'],
                "qty" => (int)$row['qty'],
                "wt" => round((float)$row['wt'], 3)
            ];
        }
    }

    echo json_encode($response);

} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}

$conn->close();
?>